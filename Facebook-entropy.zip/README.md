Press the button! Get close to your enemies or alienate your friends. 
Shed your polished facebook persona by randomly liking a third of all posts on your wall.
ARE YOU BRAVE ENOUGH TO PRESS THE BUTTON?


SCREENSHOT

![ScreenShot](/Capture.PNG "Screenshot")